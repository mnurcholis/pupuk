<?php

namespace App\Livewire\Landing\Pages;

use Livewire\Component;

class Home extends Component
{
    public function render()
    {
        return view('livewire.landing.pages.home');
    }
}
